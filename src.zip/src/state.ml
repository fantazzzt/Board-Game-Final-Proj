open Board
 
 type t = { players: player_id list; current_turn : Board.player_id;
 troops_available: Board.troops; gameboard: Board.gameboard}
(** The abstract type of values representing the game state. *)
 
(** The type representing the result of an attempted movement. *)
type deploy_result =
 | Legal of t
 | NoTroops
 | TooMany
 | NotTerr
 
let demo_st = {players = Board.players; current_turn = Board.player1;
troops_available = 10 (*Note: want to replace this with function calculating
 number of troops available*); gameboard = Board.gameboard}
 
let init_st  =  {players = Board.players; current_turn = Board.player1;
 troops_available = 10 (*Note: want to replace this with function calculating
  number of troops available*); gameboard = Board.initialization Board.gameboard}

(*The player whose turn it is*)
let whose_turn st = st.current_turn
 
(** A terr_id list of the territories owned by the current player*)
let terrs_owned st = Board.player_terrs st.gameboard st.current_turn
 
let get_gameboard brdst = brdst.gameboard
 
(*Number of troops a player has left to deploy*)
let troops_2play st = st.troops_available
 
(*Number of troops on a certain territory*)
let terr_troops terr = raise (Failure "Unimplemented")
 
(*Deploys quantity [trps] of troops to territory [terr] owned by the current player*)
let deploy (st : t) terr (trps_str : string) =
  try
    if (*[trps] is greater than troops available to deploy*)
    troops_2play st < (int_of_string trps_str)
  then
     TooMany
  else if (*[terr] is the terr_id of a territory owned by [plr]*)
    List.exists (fun terr_id -> terr_id = terr)
    (terrs_owned st) (*Would List.find be better?*)
  then (*deploy the troops, aka update state*)
    Legal {players = Board.players; current_turn = st.current_turn;
    troops_available = st.troops_available - (int_of_string trps_str);
    gameboard = Board.add_troops (st.gameboard) terr (int_of_string trps_str) (*Do we have this function or do we need to implement it?*)}
  else  NotTerr
with
  | Failure s -> NoTroops (*Number of troops not specified *)
 
 
