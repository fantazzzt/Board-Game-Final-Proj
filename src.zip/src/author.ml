let hours_worked = 150
(** This is the sum of the hours worked by each player*)